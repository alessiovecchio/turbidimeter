<?php
	$host = 'localhost:3306';
	$Username = 'root';
	$Password = 'luca1';
	$name ='turbidimeterdb';
?>