<?php
	require_once __DIR__ . "/php/config.php";
	require_once DIR_UTIL . "dataManagerDB.php";
    
	$turbidimetersTimestamp = array(); //Variabile in cui memorizzo il turbidimetersTimestamp[$turbidimeterIDfolder] dell'ultimo valore ricevuto tramite rsync e inserito nel DB
	//Mi faccio un array di timestamp per scrivere l'ultimo valore che inserisco nel DB per tale turbidimetro e poi vado ad aggiornare da lì in poi



		$turbidimeterIDfolders = scandir("./values");

		foreach($turbidimeterIDfolders as $turbidimeterIDfolder){
			if ($turbidimeterIDfolder == '.' || $turbidimeterIDfolder == '..' || $turbidimeterIDfolder[0] == '.') 
				continue;
			if(!array_key_exists($turbidimeterIDfolder, $turbidimetersTimestamp))
				$turbidimetersTimestamp[$turbidimeterIDfolder] = null;
			
			$dayFolders = scandir("./values/" . $turbidimeterIDfolder);

			
			foreach ($dayFolders as $dayFolder) {
				// Ignoro le cartelle e i file nascosti
				if ($dayFolder == '.' || $dayFolder == '..' || $dayFolder[0] == '.') {
					continue;
				}

	
				$filesFolders = scandir("./values/" . $turbidimeterIDfolder. "/" . $dayFolder);

				$folderDate = new DateTime($dayFolder);
				
				if($turbidimetersTimestamp[$turbidimeterIDfolder] != null && $folderDate->format('Y-m-d') < $turbidimetersTimestamp[$turbidimeterIDfolder]->format('Y-m-d'))
					continue;
				
				foreach ($filesFolders as $filesFolder) {
					if ($filesFolder == '.' || $filesFolder == '..' || $filesFolder[0] == '.') {
						continue;
					}

					$index = 0;
					while($index < strlen($filesFolder) && $filesFolder[$index] != ".")
						$index++;
					$dateTimestamp = DateTime::createFromFormat('Y-m-d H-i-s', $dayFolder . " " . substr($filesFolder, 3, $index-3));
			        //controllo se la data è piu recente o meno di ultimo dato inserito, nel caso inserisco i nuovi valori

					global $turbidimeterDataDb;
					if (!$turbidimeterDataDb->isOpened()) {
						try {
							echo "apro la connessione";
							$mysql = $turbidimeterDataDb->openConnection();
						} catch (Exception $e) {
							$e . getNotifications();
						}
					}else {
							$mysql = $turbidimeterDataDb->getConnection();
						}

					$stmt = $mysql->prepare("SELECT ultimoDato FROM `turbidimeterdb`.`turbidimeters` WHERE turbidimeterID = ? ");
					 $stmt->bindParam(1, $turbidimeterIDfolder, PDO::PARAM_INT);
					 $stmt->execute();
					 $row = $stmt->fetch(PDO::FETCH_ASSOC);
					 $ultimoDatoInserito = $row["ultimoDato"];
					 $timestampUltimoDato = strtotime($ultimoDatoInserito);

					 $dateTimestampFile = strtotime($dateTimestamp->format('Y-m-d H:i:s'));
					 //controllo di aggiugere solo gli ultimi dati inviati dal turbidimetro
					 if($timestampUltimoDato >= $dateTimestampFile)
					  continue;
					   else
					   echo "ho inserito " . $dayFolder. ' ' . $dateTimestamp->format('Y-m-d H:i:s');


					
					$readValues = array();
				
					$file = fopen("./values/" . $turbidimeterIDfolder . "/" . $dayFolder . "/" . $filesFolder, "r");

					if ($file) {
						while (($line = fgets($file)) !== false) {
							$words = explode(' ', $line);
			
							foreach ($words as $word) {
							array_push($readValues, $word);
							}
						}
		
						fclose($file);
					}


				$stmt = $mysql->prepare("INSERT INTO `turbidimeterdb`.`data`(turbidimeterID, timestamp, sensor, infraredOFF, ".
					"visibleOFF, fullSpectrumOFF, infraredON, visibleON, fullSpectrumON) VALUES(?, ?, 1, ?, ?, ?, ?, ?, ?);");
					 $stmt->bindParam(1, $turbidimeterIDfolder, PDO::PARAM_INT);
					 $timestamp = $dateTimestamp->format('Y-m-d H:i:s');
					 $stmt->bindParam(2,$timestamp, PDO::PARAM_STR);
					 $var0 = intval($readValues[0]);
					 $stmt->bindParam(3, $var0, PDO::PARAM_INT);
					 $var1 = intval($readValues[1]);
				 	 $stmt->bindParam(4, $var1, PDO::PARAM_INT);
					 $var2 = intval($readValues[2]);
					 $stmt->bindParam(5, $var2, PDO::PARAM_INT);
					 $var3 = intval($readValues[3]);
					 $stmt->bindParam(6, $var3, PDO::PARAM_INT);
					 $var4 = intval($readValues[4]);
					 $stmt->bindParam(7, $var4, PDO::PARAM_INT);
					 $var5 = intval($readValues[5]);
					 $stmt->bindParam(8, $var5, PDO::PARAM_INT);
					 //var_dump($turbidimeterIDfolder,  $timestamp,  $var0,  $var1,  $var2,  $var3,  $var4, $var5);
					//var_dump($turbidimeterIDfolder,  $timestamp,  intval($readValues[6]),  intval($readValues[7]),  intval($readValues[8]),  intval($readValues[9]), intval($readValues[10]), intval($readValues[11]));
					 $stmt->execute();
					 $stmt->closeCursor();

					 $stmt = $mysql->prepare("INSERT INTO `turbidimeterdb`.`data`(turbidimeterID, timestamp, sensor, infraredOFF, ".
						"visibleOFF, fullSpectrumOFF, infraredON, visibleON, fullSpectrumON) VALUES(?, ?, 3, ?, ?, ?, ?, ?, ?);");
					$stmt->bindParam(1, $turbidimeterIDfolder, PDO::PARAM_INT);
					$timestamp = $dateTimestamp->format('Y-m-d H:i:s');
					$stmt->bindParam(2,$timestamp, PDO::PARAM_STR);
					$var6 = intval($readValues[6]);
					$stmt->bindParam(3, $var6, PDO::PARAM_INT);
					$var7 = intval($readValues[7]);
					$stmt->bindParam(4, $var7, PDO::PARAM_INT);
					$var8 = intval($readValues[8]);
					$stmt->bindParam(5, $var8, PDO::PARAM_INT);
					$var9 = intval($readValues[9]);
					$stmt->bindParam(6, $var9, PDO::PARAM_INT);
					$var10 = intval($readValues[10]);
					$stmt->bindParam(7, $var10, PDO::PARAM_INT);
					$var11 = intval($readValues[11]);
					$stmt->bindParam(8, $var11, PDO::PARAM_INT);
					//var_dump($turbidimeterIDfolder,  $timestamp,  $var6,  $var7,  $var8,  $var9,  $var10, $var11);
					$stmt->execute();
					$stmt->closeCursor();
                  if(isset($readValues[12])) {
					  $stmt = $mysql->prepare("INSERT INTO `turbidimeterdb`.`voltage`(turbidimeterID,voltage, timestamp)" .
						  "VALUES(?, ?, ?);");
					  $stmt->bindParam(1, $turbidimeterIDfolder, PDO::PARAM_INT);
					  $voltage = floatval($readValues[12]);
					  $stmt->bindParam(2, $voltage, PDO::PARAM_INT);
					  $timestamp = $dateTimestamp->format('Y-m-d H:i:s');
					  $stmt->bindParam(3, $timestamp, PDO::PARAM_INT);
					  $stmt->execute();
					  $stmt->closeCursor();
				  }
				//controllo che latitudine e longitudine esistano, altrimenti stiamo parlando di un turbidimetro fisso
					//controllo che latitudine e longitudine esistano, altrimenti stiamo parlando di un turbidimetro fisso
					if (isset($readValues[13]) && isset($readValues[14])) {
						$stmt = $mysql->prepare("UPDATE `turbidimeterdb`.`turbidimeters`" .
							"SET latitudine = ?, longitudine = ?, ultimoDato = ?  WHERE turbidimeterID = ?;");
						$stringlat = substr($readValues[13], 0, 2) . "." . substr($readValues[13], 2, 2) .
							substr($readValues[13], 5, 4);
						$lat = floatval($stringlat);
						$stmt->bindParam(1, $lat, PDO::PARAM_INT);
						$stringlon = substr($readValues[14], 0, 2) .".". substr($readValues[14], 2, 2) .
							substr($readValues[14], 5, 4);
						$lon = floatval($stringlon);
						$stmt->bindParam(2, $lon, PDO::PARAM_INT);
						$timestamp = $dateTimestamp->format('Y-m-d H:i:s');
						$stmt->bindParam(3, $timestamp, PDO::PARAM_STR);
						$stmt->bindParam(4, $turbidimeterIDfolder, PDO::PARAM_INT);
						$stmt->execute();
						$stmt->closeCursor();
					} else {
						$stmt = $mysql->prepare("UPDATE `turbidimeterdb`.`turbidimeters`" .
							"SET ultimoDato = ?  WHERE turbidimeterID = ?;");
						$timestamp = $dateTimestamp->format('Y-m-d H:i:s');
						$stmt->bindParam(1, $timestamp, PDO::PARAM_STR);
						$stmt->bindParam(2, $turbidimeterIDfolder, PDO::PARAM_INT);
						$stmt->execute();
						$stmt->closeCursor();
					}

				 $turbidimeterDataDb->closeConnection();
				}
		
			}
		}

	
?>	
